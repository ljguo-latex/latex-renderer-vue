import { CharMap, ChtmlCharOptions } from '@mathjax/src/mjs/output/chtml/FontData.js';
export declare const scriptBold: CharMap<ChtmlCharOptions>;
