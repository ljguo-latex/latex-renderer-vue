import { CharMap, SvgCharOptions } from '@mathjax/src/cjs/output/svg/FontData.js';
export declare const fraktur: CharMap<SvgCharOptions>;
